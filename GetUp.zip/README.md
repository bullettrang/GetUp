# GetUp
A Google Chrome Extension App that reminds you to Get off your chair and move. Displays fun facts in notification window
